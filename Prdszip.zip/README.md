## Pro-Descriptor Project
 This is a social application to know and explore project ideas by posting the project descriptions and get connected to professionals.

### Procedure 
* Install the required software (MAMP/XAMPP, SQL Server 2005,)
* Develop HTML code * Use PHP's development server with templates
 * Create and develop schema* Create the database

 and connect to it
* Write and delete posts


* User registration
* Login
* Logout
 * View and edit your profile* 